Jack Gentsch, Jacky Wang, Chinh Bui
EE 469 Peckol Spring 2016

This folder contains the turn-in files for lab 2
Note that files ending in Demo are able to run on the DE1-SoC, while GTK files are for simulation in iVerilog and GTKWave.

The integrated memory module is contained in memory.v
The register file is in regfile.v
The SRAM is in sram.v

Major submodules include decoder, mux32, and register.